# Prompt 10: Weekly Planner

---
Plan my content week.
Inputs: last week's filmed and skipped scripts, my edits, this week's research keepers, and 3 to 5 news links (below).

Return:
1. What worked and what to stop, based only on the data I gave you
2. This week's batch list: [N] scripts, each with format, reference URL, topic, and CTA
3. Film-by dates for each script (I film on [day])
4. A posting schedule (I post [N] times a week on [platforms])
5. One experiment to run this week and how I will know if it worked

DATA:
[paste]
