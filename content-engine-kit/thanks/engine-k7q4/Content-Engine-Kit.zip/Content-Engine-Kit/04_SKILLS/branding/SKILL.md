---
name: branding
description: >-
  Use when creating or checking the brand kit: colors, fonts, on-screen text rules, safe zones, captions, and reusable templates.
---
# Workflow 8: Branding

**Why:** People follow what they recognize. Consistent colors, type, on-screen text, and captions make every piece look like it came from the same brand, even when formats change.

**Time:** 60 minutes once, then a 5-minute check per batch.

## Steps
1. **Write a one-page brand kit** with Prompt 09, using 05_TEMPLATES/brand-intake.md:
    - 2 to 3 brand colors (hex), one accent, one background
    - 1 headline font and 1 body font (free Google Fonts work well)
    - On-screen text style: case, max words per line, placement, safe zones (keep text out of the top and bottom 250 px on a 1080x1920 frame)
    - Caption style: first line is the hook, short lines, one CTA, no wall of hashtags
    - Voice rules: copied from your do-not-say list
2. **Make 3 reusable templates** in any free design tool: a story frame, a carousel slide, and a reel cover. Use the same colors and fonts every time.
3. **Add brand checks to QA:** colors, fonts, text inside safe zones, and the CTA wording matches the script.

## Output
`brand-kit.md` and three templates you reuse every week.


## Before you start
Read the brand files first: brand-intake.md, phrase-bank.md, the do-not-say list, format-vault.csv, and hook-bank.csv. If a required input is missing, stop and ask for it. Never invent stats, quotes, results, or voice lines. Mark gaps [CONFIRM]. No em dashes in anything you write. The human approves every script before it is filmed.

## Prompts this skill uses
# Prompt 09: Brand Kit

---
Using my brand intake (in project knowledge), write a one-page brand kit:
1. Colors: 2 to 3 brand colors, 1 accent, 1 background, with hex codes and where each is used
2. Fonts: 1 headline, 1 body (free Google Fonts), with sizes for story, carousel, and reel text
3. On-screen text rules: case, max words per line, placement, safe zones for 1080x1920 (keep text out of the top and bottom 250 px)
4. Caption rules: hook first line, short lines, one CTA, hashtag policy
5. Voice rules: from my do-not-say list
6. A 10-item checklist I can run before posting anything

No em dashes.

