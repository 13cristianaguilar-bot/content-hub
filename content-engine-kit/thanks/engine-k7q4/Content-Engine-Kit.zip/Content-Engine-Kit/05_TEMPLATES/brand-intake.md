# Brand Intake

Fill every field. Write [CONFIRM] where you are unsure. Do not guess.

## 1. Who you are
- Name / brand:
- Handle(s):
- One-line bio:
- Brand thesis (what you stand for, who you help, your different way):

## 2. Offer and CTA
- Main offer (what, price range optional, who it is for):
- The one action viewers should take (follow, DM a word, link in bio, book a call):
- Lead magnet (if any):
- CTA options by topic (topic -> CTA):

## 3. Audience (ICPs)
For each of 1 to 3 audiences:
- Who they are:
- What they want:
- What they are stuck on:
- Words they use to describe the problem:

## 4. Voice
- Sources you will mine (list the actual files, calls, or videos):
- 5 lines you say all the time:
- Energy (calm, intense, funny, direct):
- Words you never use:

## 5. Rules (do-not-say)
- Claims you cannot make:
- Topics you avoid:
- Tone to avoid:
- Industry or legal rules:

## 6. Formats you will film (pick 3 to 5)
- [ ] Talking-head list
- [ ] Myth-buster
- [ ] Story
- [ ] Reaction
- [ ] Tutorial or how-to
- [ ] Interview
- [ ] Other:

## 7. Filming reality
- Days you can film:
- Where you film:
- Who films (you, phone on tripod, a helper):
- Max length you are comfortable with:

## 8. Creators to study
- In-niche (5 to 15 handles):
- Cross-niche, same formats (5 to 15 handles):

## 9. Content Hub
- Where it lives (Google Sheets, Notion, Airtable):
- Link:
