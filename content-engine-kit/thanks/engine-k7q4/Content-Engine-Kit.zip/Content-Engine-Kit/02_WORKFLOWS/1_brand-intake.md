# Workflow 1: Brand Intake (do this once, update monthly)

**Why:** Every script downstream borrows its voice, offer, and rules from this file. If intake is thin, the scripts sound like AI. If intake is rich, they sound like you.

**Time:** 45 to 60 minutes the first time. 10 minutes a month to update.

**Tools:** Your AI assistant. Optional: a transcription tool for old calls or voice notes (free options in the Cost Breakdown).

## Inputs
- 3 or more pieces of you talking naturally: sales calls, coaching calls, podcast clips, voice memos, or your best-performing videos (transcripts are fine)
- Your offer and the one action you want viewers to take
- 2 to 5 creators you admire (in or out of your niche)

## Steps
1. **Open 05_TEMPLATES/brand-intake.md** and fill every section you can. Mark anything you are unsure about as [CONFIRM]. Do not guess.
2. **Build your phrase bank.** Paste your transcripts into your AI with Prompt 01 (03_PROMPTS/01_voice-and-phrase-bank.md). It pulls 30 to 60 lines you actually say, grouped by theme. Keep them word for word.
3. **Write your brand thesis.** One or two sentences: what you stand for and who you help. Example shape: "I help [who] get [result] by [your different way]."
4. **List your do-not-say rules.** Claims you cannot make, words you hate, topics you avoid, tone to avoid (for example hype, guru declarations, income claims).
5. **Lock 3 to 5 formats** you are willing to film (talking head list, myth-buster, reaction, story, tutorial, interview). You will look for proof of these in Workflow 2.
6. **Pick one CTA per topic.** The promise in the CTA must match the topic of the video.
7. **Save the finished intake** as a file inside your Claude Project, custom GPT knowledge, or repo. Every other workflow reads it.

## Gate (do not move on until all are true)
- Phrase bank has at least 30 verbatim lines from real sources
- Offer and CTA are filled or clearly marked [CONFIRM]
- Do-not-say list exists
- 3 to 5 formats are locked

If any of these are missing, stop. Writing scripts without them is how you get generic AI content.

## Output
`brand-intake.md` (filled), `phrase-bank.md`, and your locked format list.
