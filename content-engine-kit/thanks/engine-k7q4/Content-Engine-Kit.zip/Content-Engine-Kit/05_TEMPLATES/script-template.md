# Script: [Plain-English title]

- Status: Draft / Needs Review / Approved / Filmed / Posted
- Film by: [date]
- Format: [format name]
- CTA: [one action]

## On-screen hook (first 3 seconds)
[text]

## Teleprompter script
[Only the words you will say. Short lines. No directions.]

## Filming notes
- Framing:
- Energy:
- Props or setting:
- Optional B-roll ideas (park these if this is a talking-head batch):

## Reference (Media Lock)
- URL:
- Views / creator median / multiple:
- Length (s):
- Spoken hook (from audio):
- On-screen text:
- Format components:

## Audits
- Hook audit: reference "[ ]" vs mine "[ ]": MATCH / DRIFT
- Length: [words] words, about [s] seconds vs reference [s] (ratio [ ])
- Voice Lock: [N] mid-body lines from phrase bank: [list]
- Claims check: [any claim and its source]
- [CONFIRM] gaps:
