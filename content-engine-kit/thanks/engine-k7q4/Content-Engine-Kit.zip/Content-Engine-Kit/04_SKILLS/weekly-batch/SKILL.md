---
name: weekly-batch
description: >-
  Use when producing the weekly batch of 3 to 10 ready-to-film scripts from fresh research, news, and last week edits.
---
# Workflow 6: Weekly Batch

**Why:** Consistency beats bursts. One batch day a week produces everything you film the next week.

**Time:** 2 to 3 hours once a week.

## Steps
1. **Read last week's notes first:** what you filmed, what you skipped, what felt off, and any edits you made to scripts. Edits are signal about your voice.
2. **Refresh research:** pull the last 30 reels for yourself and 5 to 15 competitors. Keep formats with 2 or more reels at 3x+ median.
3. **Pull this week's news** in your niche (3 to 5 stories) and save the source links. Trends give you topics; recipes give you structure.
4. **Pick the batch:** 3 scripts for light use, 5 to 7 for medium, 7 to 10 for heavy. Turn any unfilmed, edit-heavy ideas into simple talking-head versions first, then add trend ideas.
5. **Write each script** with Workflow 5. Each one needs a real reference reel with 100K+ views and a strong multiple.
6. **Run the batch QA** with Prompt 08 (format fidelity, hook audit, voice check, claims check, [CONFIRM] gaps).
7. **Load the Content Hub:** new scripts go in as Needs Review with a film-by date.
8. **Read every script yourself,** then move the ones you approve to Approved. Those are next week's filming list.

## Talking-head rule
Every script in a talking-head batch must be filmable to camera with just a phone. Park anything that needs B-roll or editing in a separate idea list.

## Output
A weekly batch file (05_TEMPLATES/weekly-batch.md) and 3 to 10 Approved scripts in your Hub.


## Before you start
Read the brand files first: brand-intake.md, phrase-bank.md, the do-not-say list, format-vault.csv, and hook-bank.csv. If a required input is missing, stop and ask for it. Never invent stats, quotes, results, or voice lines. Mark gaps [CONFIRM]. No em dashes in anything you write. The human approves every script before it is filmed.

## Prompts this skill uses
# Prompt 10: Weekly Planner

---
Plan my content week.
Inputs: last week's filmed and skipped scripts, my edits, this week's research keepers, and 3 to 5 news links (below).

Return:
1. What worked and what to stop, based only on the data I gave you
2. This week's batch list: [N] scripts, each with format, reference URL, topic, and CTA
3. Film-by dates for each script (I film on [day])
4. A posting schedule (I post [N] times a week on [platforms])
5. One experiment to run this week and how I will know if it worked

DATA:
[paste]


# Prompt 08: Batch QA

---
Run QA on this week's batch. For each script return a row:
title | Media Lock (yes/no) | hook audit (MATCH/DRIFT) | length ratio | voice check (PASS/FAIL, mid-body count) | thesis fit (PASS/FAIL) | claims check (any unsourced claim?) | CTA matches topic (yes/no) | [CONFIRM] gaps | verdict (READY FOR MY READ / FIX)

Do not mark anything READY if Media Lock is missing, the hook drifted, voice failed, or a claim is unsourced. Then list the fixes in priority order.

BATCH:
[paste scripts with their reference details]

