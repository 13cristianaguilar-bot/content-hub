# Workflow 2: Outlier Research

**Why:** Views tell you what an audience already wants. An outlier is a reel that beat its own creator's normal by a wide margin, so the format and idea did the work, not just the follower count.

**Time:** 30 to 60 minutes per research run. Run it every 1 to 2 weeks.

## The ranking rule
An **outlier** is a reel with:
- **At least 3x the creator's median views** (median of their other recent reels, about the last 30 to 50), and
- **At least 100,000 views** for anything you will copy a hook or structure from.

Also note view tiers (100K, 1M, 10M) and skip reels under about 3 days old, because their numbers are still moving.

## Three ways to get the data (pick one)

| Option | Cost | Best for |
|---|---|---|
| A. Manual (free) | $0 | Light use. Open each creator's reels tab, write down views for the last 30 reels in 05_TEMPLATES/outlier-log.csv, then run the median math with Prompt 02 or tools/outliers.py |
| B. Apify Instagram Reel Scraper | Pay per result (see Cost Breakdown) | Medium and heavy use. Scrapes many creators at once and exports JSON or CSV |
| C. Bright Data Instagram Reels scraper | Free tier, then pay per 1K records (see Cost Breakdown) | An alternative to Apify with a monthly free record allowance |
| Optional: Sandcastles | Subscription with monthly credits | A research app with an outlier database, channel recaps, and transcripts. Good if you prefer an app to spreadsheets |

## Steps
1. **Build your creator list.** 10 to 30 handles: in-niche creators about your size or a little bigger, plus cross-niche creators who use your locked formats. Save to `handles.txt`, one per line.
2. **Pull the last 30 to 50 reels per creator** with the option you picked. Set a spend cap before any paid run (Apify and Bright Data both let you cap a run or a month).
3. **Rank.** Either run `python3 tools/outliers.py data/*.json --out out/batch-01` on scraper exports, or paste your outlier-log.csv into your AI with Prompt 02. You get each reel's views, the creator's median, the multiple, and a flag for 3x+.
4. **Look at the winners.** Open every 3x+ reel. Watch the first 10 seconds with sound on.
5. **Do the 7-part breakdown** for each keeper with Prompt 03: hook, format, idea, reward, CTA, angle, messaging. Keep hook, format, idea, reward, and CTA. Angle and messaging are the parts you will rewrite.
6. **Save keepers** to your Format Vault (05_TEMPLATES/format-vault.csv) with the URL, views, median, multiple, and the date you checked.

## Gate
- Every keeper has a live URL, views, creator median, and multiple written down
- You verified the owner and the like count on the reel itself (index numbers can be wrong; a reel with hundreds of thousands of views and a few dozen likes is not verified)
- You watched or transcribed the opening. The caption is never the hook

## Output
A ranked list (CSV), a short list of keepers with 7-part breakdowns, and new rows in your Format Vault.
