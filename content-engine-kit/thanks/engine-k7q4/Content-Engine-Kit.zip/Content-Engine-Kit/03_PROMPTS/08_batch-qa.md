# Prompt 08: Batch QA

---
Run QA on this week's batch. For each script return a row:
title | Media Lock (yes/no) | hook audit (MATCH/DRIFT) | length ratio | voice check (PASS/FAIL, mid-body count) | thesis fit (PASS/FAIL) | claims check (any unsourced claim?) | CTA matches topic (yes/no) | [CONFIRM] gaps | verdict (READY FOR MY READ / FIX)

Do not mark anything READY if Media Lock is missing, the hook drifted, voice failed, or a claim is unsourced. Then list the fixes in priority order.

BATCH:
[paste scripts with their reference details]
