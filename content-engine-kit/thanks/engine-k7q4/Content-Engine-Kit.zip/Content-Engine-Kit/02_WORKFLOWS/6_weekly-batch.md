# Workflow 6: Weekly Batch

**Why:** Consistency beats bursts. One batch day a week produces everything you film the next week.

**Time:** 2 to 3 hours once a week.

## Steps
1. **Read last week's notes first:** what you filmed, what you skipped, what felt off, and any edits you made to scripts. Edits are signal about your voice.
2. **Refresh research:** pull the last 30 reels for yourself and 5 to 15 competitors. Keep formats with 2 or more reels at 3x+ median.
3. **Pull this week's news** in your niche (3 to 5 stories) and save the source links. Trends give you topics; recipes give you structure.
4. **Pick the batch:** 3 scripts for light use, 5 to 7 for medium, 7 to 10 for heavy. Turn any unfilmed, edit-heavy ideas into simple talking-head versions first, then add trend ideas.
5. **Write each script** with Workflow 5. Each one needs a real reference reel with 100K+ views and a strong multiple.
6. **Run the batch QA** with Prompt 08 (format fidelity, hook audit, voice check, claims check, [CONFIRM] gaps).
7. **Load the Content Hub:** new scripts go in as Needs Review with a film-by date.
8. **Read every script yourself,** then move the ones you approve to Approved. Those are next week's filming list.

## Talking-head rule
Every script in a talking-head batch must be filmable to camera with just a phone. Park anything that needs B-roll or editing in a separate idea list.

## Output
A weekly batch file (05_TEMPLATES/weekly-batch.md) and 3 to 10 Approved scripts in your Hub.
