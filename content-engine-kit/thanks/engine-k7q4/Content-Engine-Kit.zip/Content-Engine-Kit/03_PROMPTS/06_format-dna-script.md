# Prompt 06: Format DNA Script Writer

---
Write one short-form talking-head script using Format DNA.

PROJECT KNOWLEDGE TO USE: my brand intake, phrase bank, do-not-say list, and the recipe card for this format.

REFERENCE (Media Lock):
- URL: [ ]
- Length: [ ] seconds
- Spoken hook (from audio): "[ ]"
- On-screen text: "[ ]"
- Format components I saw: [ ]
- Transcript: [ ]

KEEP from the reference: hook principle, format beats in order, rehook, cadence, length (target [reference seconds x 2.5] words, within 0.75x to 1.25x), idea, reward, emotional next step.
CHANGE: message, angle, and voice to fit my brand thesis.

VOICE LOCK: weave at least 3 lines from my phrase bank into the MIDDLE of the script (after the hook, before the CTA). Quote them as close to word for word as possible. Do not bolt signature lines onto the end.

TOPIC: [this week's topic or news link]
CTA: [my CTA for this topic]

Return in this order:
1. Title (plain English)
2. On-screen hook (text in first 3 seconds)
3. TELEPROMPTER SCRIPT (only words I will say, short lines, no stage directions)
4. Filming notes (framing, energy, props, any B-roll ideas)
5. Hook audit: reference spoken hook vs my opening line, side by side, MATCH or DRIFT
6. Voice audit: list the phrase-bank lines used and where
7. Word count and estimated seconds vs reference length
8. Anything you were unsure of, marked [CONFIRM]

Rules: no em dashes, no hype, no income claims, no claims I have not given you, no guru absolutes.
