---
name: format-dna-scripts
description: >-
  Use when writing or rewriting a talking-head script from a proven reference reel: keep hook, beats, length, and payoff; change only message, angle, and voice; pass Media, Voice, and Thesis locks.
---
# Workflow 5: Format DNA Scripts

**Why:** Most AI scripts fail because they copy the topic and lose the structure, or keep the structure and lose the voice. Format DNA keeps the machine that earned the views and fuels it with your message and your words.

**Time:** 15 to 25 minutes per script, including your read-through.

## The Format DNA checklist
Keep all of these from the reference reel:
- **Hook** (the spoken hook principle; your opening line should match it)
- **Format beats** (the order of moves: setup, list, twist, proof, payoff)
- **Rehook** (the mid-video line that re-earns attention)
- **Cadence** (sentence length and rhythm)
- **Length** within 0.75x to 1.25x of the reference (estimate about 2.5 spoken words per second)
- **Idea** and **reward** (what the viewer gets)
- **Emotional next step** (how the viewer should feel at the end)

Change only these: **message, angle, and voice.**

## Three locks before anything is called finished
1. **Media Lock.** You heard or transcribed the first 10 seconds of the reference. You have the spoken hook word for word, the length in seconds, and the visible format components. Caption-only research is discovery, not a lock.
2. **Voice Lock.** At least 3 real lines from your phrase bank, calls, or posts are woven into the **middle** of the script (after the hook, before the CTA). Gluing a signature line onto the end of an AI body does not count.
3. **Thesis Lock.** The script fits your brand thesis. If the reference creator's topic does not fit you, keep their structure and fill it with your thesis. If you cannot do that honestly, pick a different reference.

## Steps
1. Load your brand intake, phrase bank, do-not-say list, and the recipe card for the format.
2. Paste the reference transcript and Media Lock details into Prompt 06.
3. The AI writes: on-screen hook, spoken hook, full body at matched length, CTA tied to your offer, and filming notes. Gaps are marked [CONFIRM].
4. Run the **hook audit**: put the reference spoken hook and your new opening line side by side. If the structure drifted, fix the hook before anything else.
5. Run the **voice check** with Prompt 07. It lists which mid-body lines came from your real words and flags AI phrasing (hedges like "gently disagree," hype, em dashes, guru absolutes, income claims).
6. Read it out loud. If you would not say it that way, change it.

## Output
A script in 05_TEMPLATES/script-template.md format: title, film-by date, on-screen hook, teleprompter script (clean), filming notes (separate), reference link and metrics, CTA.

**Teleprompter rule:** the script field contains only words you will say. Directions, notes, and explanations go in filming notes.


## Before you start
Read the brand files first: brand-intake.md, phrase-bank.md, the do-not-say list, format-vault.csv, and hook-bank.csv. If a required input is missing, stop and ask for it. Never invent stats, quotes, results, or voice lines. Mark gaps [CONFIRM]. No em dashes in anything you write. The human approves every script before it is filmed.

## Prompts this skill uses
# Prompt 06: Format DNA Script Writer

---
Write one short-form talking-head script using Format DNA.

PROJECT KNOWLEDGE TO USE: my brand intake, phrase bank, do-not-say list, and the recipe card for this format.

REFERENCE (Media Lock):
- URL: [ ]
- Length: [ ] seconds
- Spoken hook (from audio): "[ ]"
- On-screen text: "[ ]"
- Format components I saw: [ ]
- Transcript: [ ]

KEEP from the reference: hook principle, format beats in order, rehook, cadence, length (target [reference seconds x 2.5] words, within 0.75x to 1.25x), idea, reward, emotional next step.
CHANGE: message, angle, and voice to fit my brand thesis.

VOICE LOCK: weave at least 3 lines from my phrase bank into the MIDDLE of the script (after the hook, before the CTA). Quote them as close to word for word as possible. Do not bolt signature lines onto the end.

TOPIC: [this week's topic or news link]
CTA: [my CTA for this topic]

Return in this order:
1. Title (plain English)
2. On-screen hook (text in first 3 seconds)
3. TELEPROMPTER SCRIPT (only words I will say, short lines, no stage directions)
4. Filming notes (framing, energy, props, any B-roll ideas)
5. Hook audit: reference spoken hook vs my opening line, side by side, MATCH or DRIFT
6. Voice audit: list the phrase-bank lines used and where
7. Word count and estimated seconds vs reference length
8. Anything you were unsure of, marked [CONFIRM]

Rules: no em dashes, no hype, no income claims, no claims I have not given you, no guru absolutes.


# Prompt 07: Voice Check

---
Check this script against my phrase bank and voice profile (in project knowledge).

1. Mark every line as MINE (from my real words, cite the phrase-bank line), CLOSE (my idea, new wording), or AI (generic).
2. Count MINE lines in the middle of the script (after the hook, before the CTA). PASS needs 3 or more.
3. FAIL if the only MINE lines are at the very end (bolt-on).
4. Flag AI patterns: hedges ("gently," "quietly disagree"), hype, em dashes, talking down to the viewer, guru absolutes, income claims, anything on my do-not-say list.
5. Rewrite only the AI lines using my phrase bank. Do not touch the hook structure.

Return: PASS or FAIL, the counts, the flagged lines, and the revised script.

SCRIPT:
[paste]

