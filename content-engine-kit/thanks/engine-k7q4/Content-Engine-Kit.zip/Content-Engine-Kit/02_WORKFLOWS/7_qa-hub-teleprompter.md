# Workflow 7: QA, Content Hub, and Teleprompter

**Why:** "The AI finished the steps" is not a quality bar. A person reads every script before it is filmed. A simple Hub keeps everyone (you, a client, an editor) looking at the same list.

## The QA checklist (every script)
1. Media Lock on file: reference URL, length, spoken hook, format components
2. Format DNA kept: hook, beats, rehook, cadence, length 0.75x to 1.25x, idea, reward
3. Thesis fits your brand. No foreign-world nouns pasted from the reference creator's niche
4. Voice Lock: 3+ real lines in the mid-body, not bolted on at the end
5. No unsourced claims, no income claims, no em dashes, no hype
6. CTA promise matches the topic
7. Read it out loud as if filming. Would you say it like that?
8. Only then mark it Approved

## The Content Hub (no code needed)
Make it from 05_TEMPLATES/content-hub-tracker.csv in Google Sheets, Notion, or Airtable. One row per script.

| Column | Use |
|---|---|
| Title | Plain-English title you would recognize |
| Status | Draft, Needs Review, Approved, Filmed, Posted |
| Film by | Date |
| Script | Teleprompter text only |
| Filming notes | Framing, props, energy, B-roll ideas |
| Reference | URL plus views, median, multiple |
| On-screen hook | The text in the first 3 seconds |
| CTA | The one action |
| Edits | What you changed when filming (feeds next week's batch) |

**Rules that keep the Hub clean**
- The filming list is only Approved scripts with a film-by date, sorted by date.
- When you edit a script, keep the original in an "Original" column or version history so you can compare.
- Only the person running QA changes Status.
- If you deliver scripts to clients, give them view or comment access, not edit access to Status.

## Teleprompter
Open tools/teleprompter.html in any browser (phone or laptop). Paste the Script column, set the speed, and film. It runs offline and costs nothing.

## Output
Approved scripts in the Hub, filmed from a clean teleprompter.
