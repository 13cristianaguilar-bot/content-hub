# Prompt 05: Hook Matcher

---
I have a short-form clip about: [what the first 3 seconds actually show or say].

Here are verified source hooks (100K+ views, 3x+ creator median, owner and likes checked on the reel):
1. "[exact on-screen text]" | [URL] | views [ ] | median [ ] | multiple [ ]
2. ...

For each source hook:
1. Name the formula (for example "How [X] affects [Y]").
2. Name the emotion trigger (curiosity gap, "that's me," or rule-break).
3. Write one adapted hook for my clip. Keep the skeleton and emotion. Swap only the nouns.
4. Say whether my clip pays off the adapted hook in the first 3 seconds. If not, say so and drop it.

Recommend the best two to test against each other. Do not invent new hooks that are not built on a source above.
