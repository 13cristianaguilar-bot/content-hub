# Workflow 3: Success Recipes

**Why:** One viral video can be luck. A creator who hit an outlier, then reused the same format and kept growing, has a recipe. Recipes are what you build a content plan on.

**Time:** 30 to 45 minutes per format, monthly.

## Inputs
- Your 3 to 5 locked formats (from Brand Intake)
- Your brand thesis (filters out topics that do not fit you, even if the format fits)
- Outlier research output (Workflow 2)

## Steps
1. **For each locked format, seed two lists of creators:**
    - In-niche growers: same audience as you
    - Cross-niche growers: different topic, same format, clearly doubling down on it
2. **Run outlier research** (Workflow 2) on those handles.
3. **Apply the recipe filter with Prompt 04:** keep only creators who reused the format after an outlier. Tag each keeper with format name, niche, growth signal, and the best 2 to 3 reel URLs.
4. **Lock one primary anchor per format.** Download or watch the anchor reel and write down:
    - The spoken hook, word for word, from the audio (not the caption)
    - Length in seconds
    - On-screen text, if any
    - The format components you can see (cuts, B-roll, lists, props, framing)
   This is your **Media Lock**. No Media Lock, no recipe.
5. **Write the recipe card** (Format Vault row): format name, anchor URL, spoken hook, length, beats, payoff, and two or three backup references.

## Gate
- At least one anchor per format with a spoken-hook Media Lock on file
- Each recipe shows reuse after an outlier, not a single hit

## Output
A recipe card per format in your Format Vault. Workflow 5 writes scripts from these.
