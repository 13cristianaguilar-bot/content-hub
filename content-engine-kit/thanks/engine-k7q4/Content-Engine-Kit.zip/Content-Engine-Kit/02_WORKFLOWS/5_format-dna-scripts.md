# Workflow 5: Format DNA Scripts

**Why:** Most AI scripts fail because they copy the topic and lose the structure, or keep the structure and lose the voice. Format DNA keeps the machine that earned the views and fuels it with your message and your words.

**Time:** 15 to 25 minutes per script, including your read-through.

## The Format DNA checklist
Keep all of these from the reference reel:
- **Hook** (the spoken hook principle; your opening line should match it)
- **Format beats** (the order of moves: setup, list, twist, proof, payoff)
- **Rehook** (the mid-video line that re-earns attention)
- **Cadence** (sentence length and rhythm)
- **Length** within 0.75x to 1.25x of the reference (estimate about 2.5 spoken words per second)
- **Idea** and **reward** (what the viewer gets)
- **Emotional next step** (how the viewer should feel at the end)

Change only these: **message, angle, and voice.**

## Three locks before anything is called finished
1. **Media Lock.** You heard or transcribed the first 10 seconds of the reference. You have the spoken hook word for word, the length in seconds, and the visible format components. Caption-only research is discovery, not a lock.
2. **Voice Lock.** At least 3 real lines from your phrase bank, calls, or posts are woven into the **middle** of the script (after the hook, before the CTA). Gluing a signature line onto the end of an AI body does not count.
3. **Thesis Lock.** The script fits your brand thesis. If the reference creator's topic does not fit you, keep their structure and fill it with your thesis. If you cannot do that honestly, pick a different reference.

## Steps
1. Load your brand intake, phrase bank, do-not-say list, and the recipe card for the format.
2. Paste the reference transcript and Media Lock details into Prompt 06.
3. The AI writes: on-screen hook, spoken hook, full body at matched length, CTA tied to your offer, and filming notes. Gaps are marked [CONFIRM].
4. Run the **hook audit**: put the reference spoken hook and your new opening line side by side. If the structure drifted, fix the hook before anything else.
5. Run the **voice check** with Prompt 07. It lists which mid-body lines came from your real words and flags AI phrasing (hedges like "gently disagree," hype, em dashes, guru absolutes, income claims).
6. Read it out loud. If you would not say it that way, change it.

## Output
A script in 05_TEMPLATES/script-template.md format: title, film-by date, on-screen hook, teleprompter script (clean), filming notes (separate), reference link and metrics, CTA.

**Teleprompter rule:** the script field contains only words you will say. Directions, notes, and explanations go in filming notes.
