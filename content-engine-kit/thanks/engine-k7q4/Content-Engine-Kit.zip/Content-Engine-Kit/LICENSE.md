# License and Terms

Copyright 2026 Cristian Aguilar, Signal Marketing. All rights reserved.

You may use this kit for your own brand and for clients you serve directly. You may edit the prompts, skills, and templates for that use.

You may not resell, share, publish, or redistribute the kit, or any substantial part of it, as a product, course, template pack, or download.

No results are promised. Views, leads, and revenue depend on your offer, your delivery on camera, your consistency, and the platforms. Tool prices belong to their vendors and can change. The kit does not include video editing or any done-for-you service.

tools/outliers.py uses the 3x-median outlier method popularized by Artem Novitckii's open-source Creator Lab (MIT).
