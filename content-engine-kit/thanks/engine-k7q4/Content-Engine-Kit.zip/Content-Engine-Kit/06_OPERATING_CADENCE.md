# Run Your Marketing Team: The Weekly Operating Cadence

Think of the system as a small team. Your AI plays researcher, strategist, and writer. You play creative director and talent. This is the rhythm that keeps it moving.

## The roles
| Role | Who | Owns |
|---|---|---|
| Researcher | AI + scraper or manual log | Outlier research, success recipes, hook bank |
| Strategist | AI, approved by you | Weekly plan, formats, topics, CTAs |
| Writer | AI | Format DNA scripts, captions |
| Editor-in-chief | You | QA read, approve, voice |
| Talent | You | Filming from the teleprompter |
| Ops | You or an assistant | Content Hub, posting schedule, tracking |

## The week (about 2 to 3 hours of your time, plus filming)
| Day | Job | Workflow / prompt | Time |
|---|---|---|---|
| Monday | Review last week: filmed, skipped, edits, real numbers | Prompt 10 | 20 min |
| Monday | Research refresh: last 30 reels for you and 5 to 15 competitors | Workflow 2, Prompt 02 | 30 min |
| Tuesday | Pick the batch and write scripts | Workflow 6, Prompt 06 | 60 min |
| Tuesday | Batch QA, then your read-through | Prompts 07, 08 | 30 min |
| Wednesday | Hooks for each approved script, captions | Workflow 4, Prompt 05 | 20 min |
| Thursday | Film from the teleprompter (batch all of it) | tools/teleprompter.html | 45 to 90 min |
| Friday | Post, log results in the Hub, note edits | Content Hub | 15 min |

## Monthly
- Update your phrase bank with new calls, posts, and voice notes (Prompt 01)
- Refresh success recipes for each locked format (Workflow 3)
- Retire formats that stopped working for you; promote ones that did
- Check your tool spend against the Cost Breakdown

## Scorecard (track only real numbers)
| Metric | Where it comes from |
|---|---|
| Scripts approved | Content Hub |
| Scripts filmed | Content Hub |
| Posts published | Your platforms |
| Views per post vs your own median | Platform insights |
| Profile visits, follows, DMs, leads | Platform insights and your inbox |

Compare yourself to your own median, the same way you judge outliers. A post at 3x your median is your outlier. Study it and make more of that format.

## Rules for the team
1. No script is filmed without your read.
2. No claim is made without a source.
3. No format is called proven without the numbers.
4. Edits you make while filming go back into next week's batch.
