# Prompt 07: Voice Check

---
Check this script against my phrase bank and voice profile (in project knowledge).

1. Mark every line as MINE (from my real words, cite the phrase-bank line), CLOSE (my idea, new wording), or AI (generic).
2. Count MINE lines in the middle of the script (after the hook, before the CTA). PASS needs 3 or more.
3. FAIL if the only MINE lines are at the very end (bolt-on).
4. Flag AI patterns: hedges ("gently," "quietly disagree"), hype, em dashes, talking down to the viewer, guru absolutes, income claims, anything on my do-not-say list.
5. Rewrite only the AI lines using my phrase bank. Do not touch the hook structure.

Return: PASS or FAIL, the counts, the flagged lines, and the revised script.

SCRIPT:
[paste]
