# Prompt 02: Outlier Ranking

Use this when you collected views by hand or pasted a CSV export.

---
You are my content research analyst. Below is a list of reels with: creator handle, reel URL, post date, views.

For each creator:
1. Compute the median views of their reels in this list.
2. For each reel, compute multiple = views / median of that creator's OTHER reels.
3. Flag OUTLIER when multiple is 3 or higher.
4. Flag ELIGIBLE FOR HOOKS when it is an outlier AND views are 100,000 or more.
5. Flag TOO NEW if the reel is under 3 days old.

Return a table sorted by multiple (highest first) with columns: creator, URL, views, creator median, multiple, outlier (yes/no), eligible for hooks (yes/no), too new (yes/no).
Then list which formats look repeated by the same creator after an outlier.
Show your math for the top 5 rows so I can check it. Do not invent numbers. If data is missing, say so.

DATA:
[paste CSV or table here]
