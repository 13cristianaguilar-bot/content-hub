# Weekly Batch: Week of [date]

## Last week
- Filmed:
- Skipped (and why):
- Edits I made while filming (voice signal):
- What performed (only real numbers):

## Research refresh
- Creators scraped:
- New outliers (3x+ and 100K+):
- Repeated formats this week:

## News and trends (with links)
1.
2.
3.

## This week's batch
| # | Title | Format | Reference URL | Topic | CTA | Film by | Status |
|---|---|---|---|---|---|---|---|
| 1 | | | | | | | |
| 2 | | | | | | | |
| 3 | | | | | | | |

## QA summary
- All Media Locks on file: yes / no
- Hook audits MATCH: yes / no
- Voice checks PASS: yes / no
- [CONFIRM] items to resolve:

## Experiment this week
- What:
- How I will know:
