# Setup: Claude Code or Cursor (about 20 minutes)

Best for people who want the AI to run scripts (like tools/outliers.py), manage files, and call research tools for them.

## Folder setup
1. Create a folder called `content-engine` and copy this whole kit into it.
2. Put your filled brand-intake.md, phrase-bank.md, format-vault.csv, and hook-bank.csv in a `brand/` folder.
3. Create `data/` for scraper exports and `out/` for ranked results.

## Claude Code
1. Copy each folder in 04_SKILLS into `.claude/skills/` inside your project (for example `.claude/skills/format-dna-scripts/SKILL.md`).
2. Create `CLAUDE.md` in the project root and paste the instruction block from claude-project.md.
3. Run `claude` in the folder. Say "run outlier research on handles.txt" or "write this week's batch."

## Cursor
1. Copy each folder in 04_SKILLS into `.cursor/skills/` (or keep them in `04_SKILLS` and reference them).
2. Create `AGENTS.md` in the project root and paste the instruction block from claude-project.md, plus: "Skills for each workflow live in 04_SKILLS. Read the matching SKILL.md before starting a job."
3. Open the folder in Cursor and ask the agent for the job by name.

## Optional connectors (only if you have the accounts)
- **Apify:** connect the Apify MCP server (it signs you in with OAuth) or set an API token in your environment. Always set a spend cap.
- **Bright Data:** connect its MCP server or CLI. Use the free monthly records first.
- **Sandcastles:** its paid plans include an MCP connector.
Never paste API keys into chat or commit them to a repo. Use environment variables.

## Free local tools
- Python 3 for tools/outliers.py
- yt-dlp and ffmpeg to download a reel you are studying and grab frames at 0.3s, 1s, 2s, 3s
- Whisper (open source) to transcribe the first 30 seconds locally for free
