---
name: proven-text-hooks
description: >-
  Use when choosing on-screen text hooks for a clip by matching verified 100K+, 3x-median hook structures and swapping only the nouns.
---
# Workflow 4: Proven Text Hooks

**Why:** The on-screen text in the first 3 seconds decides whether someone keeps watching. Inventing hooks is guessing. Matching a hook structure that already earned 100K+ views is not.

**Time:** 15 to 20 minutes per clip.

## Hard rules
- Eligible source reel: **100K+ views and at least 3x the creator's median**, measured on about the last 50 reels.
- The hook is the **exact on-screen text in the first 0 to 3 seconds.** Not the caption, not the description, not the spoken subtitles.
- Verify owner and like count on the reel itself before you cite views.
- Keep the skeleton and the emotion. Swap only the nouns. Your clip must pay off the new words in the first few seconds.
- Always produce at least two hook options per clip and test them.

## Steps
1. **Know your clip.** What does the first 3 seconds actually deliver?
2. **Search by keyword** for reels in and around your topic (Instagram search, Sandcastles, or a scraper run).
3. **Check the creator median** (Workflow 2 math). Keep only 100K+ and 3x+.
4. **Verify** the URL opens the right reel, the handle matches, and the likes are believable for the views.
5. **Read the opening frames.** Pause at about 0.3s, 1s, 2s, and 3s. Copy the exact on-screen text. Skip reels with no text hook.
6. **Match the structure with Prompt 05.** Name the formula, keep the emotion (curiosity gap, "that's me," or rule-break), swap the nouns.
7. **Save every verified hook** to your Hook Bank (05_TEMPLATES/hook-bank.csv). Never add an unverified one.

## Starter formula bank
These skeletons came from verified outliers. Use them as starting points, then verify your own sources.
1. How [X] affects [Y]
2. How to tell if [person] [hidden thing]
3. My face when [expectation] and you [opposite]
4. "[Common phrase]." Most people [X]. The ones who [win] do [Y].
5. Never [common action] immediately
6. Types of [thing]: label / label / label
7. If you still want [goal] in [time], here are [N] [habits]

## Output
A hook sheet per clip: recommended hook plus at least one backup, each with formula, original text, adapted line, source URL, views, median, multiple, and emotion trigger.


## Before you start
Read the brand files first: brand-intake.md, phrase-bank.md, the do-not-say list, format-vault.csv, and hook-bank.csv. If a required input is missing, stop and ask for it. Never invent stats, quotes, results, or voice lines. Mark gaps [CONFIRM]. No em dashes in anything you write. The human approves every script before it is filmed.

## Prompts this skill uses
# Prompt 05: Hook Matcher

---
I have a short-form clip about: [what the first 3 seconds actually show or say].

Here are verified source hooks (100K+ views, 3x+ creator median, owner and likes checked on the reel):
1. "[exact on-screen text]" | [URL] | views [ ] | median [ ] | multiple [ ]
2. ...

For each source hook:
1. Name the formula (for example "How [X] affects [Y]").
2. Name the emotion trigger (curiosity gap, "that's me," or rule-break).
3. Write one adapted hook for my clip. Keep the skeleton and emotion. Swap only the nouns.
4. Say whether my clip pays off the adapted hook in the first 3 seconds. If not, say so and drop it.

Recommend the best two to test against each other. Do not invent new hooks that are not built on a source above.

