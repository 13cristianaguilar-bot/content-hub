# The Content Engine Kit: Start Here

By Cristian Aguilar, Signal Marketing

This kit is the content system I run for my clients, packaged so you can run it yourself inside your own AI. It finds short-form formats that are already working, pulls the hooks that earned the views, rewrites proven structures into your voice, and hands you a clean teleprompter script you can film the same day.

You do not need to code. You need an AI assistant (Claude, ChatGPT, or Cursor), about 60 minutes for setup, and about 2 to 3 hours a week to run it.

## What the system does, in one line per step

1. **Brand intake.** Capture your voice, offer, audience, and rules once, so every script sounds like you.
2. **Outlier research.** Find reels that did at least 3x their creator's median views, with 100K+ views.
3. **Success recipes.** Keep only formats creators reused after an outlier. Those are real formats, not luck.
4. **Proven text hooks.** Copy the exact on-screen hook structure that earned the views, then swap in your nouns.
5. **Format DNA scripts.** Keep the reference's hook, beats, length, and payoff. Change only the message, angle, and voice.
6. **Weekly batch.** Turn the research into 3 to 10 ready-to-film scripts every week.
7. **QA and delivery.** Read every script as if you were filming it, then publish it to a simple Content Hub and teleprompter.
8. **Branding.** Keep visuals, on-screen text, and captions consistent so people recognize you.

## How to use this kit

**Day 1 (about 60 minutes)**
1. Read this page and the Cost Breakdown (07_COST_BREAKDOWN.md). Decide light, medium, or heavy.
2. Pick your AI and follow its setup file in 01_SETUP:
    - Claude Projects: 01_SETUP/claude-project.md
    - ChatGPT custom GPT or Project: 01_SETUP/chatgpt-custom-gpt.md
    - Claude Code or Cursor: 01_SETUP/claude-code-and-cursor.md (copy 04_SKILLS into your project)
3. Fill in 05_TEMPLATES/brand-intake.md. This is the most important hour you will spend.
4. Make your Content Hub from 05_TEMPLATES/content-hub-tracker.csv (Google Sheets, Notion, or Airtable).

**Day 2 onward**
Follow 06_OPERATING_CADENCE.md. It tells you what to run on which day so the system works like a small marketing team.

## Folder map

| Folder | What is inside |
|---|---|
| 01_SETUP | How to load the system into Claude, ChatGPT, Claude Code, or Cursor |
| 02_WORKFLOWS | One step-by-step SOP per workflow, with the why, the steps, and the gates |
| 03_PROMPTS | Copy-paste prompts, one per job |
| 04_SKILLS | Skill files (SKILL.md) for Claude Code, Cursor, and Claude skills |
| 05_TEMPLATES | Brand intake, script template, hook bank, weekly batch, format vault, Content Hub tracker |
| tools | outliers.py (ranks reels at 3x median), teleprompter.html (free browser teleprompter) |
| 06_OPERATING_CADENCE.md | The weekly rhythm for running your marketing team |
| 07_COST_BREAKDOWN.md | Every account, free vs paid, price per plan and per credit, monthly estimates |

## The five rules that make this work

1. **A format is proven when the numbers say so.** 100K+ views and at least 3x the creator's median, checked on the reel itself.
2. **The hook is what the person said or showed in the first 3 seconds.** Never the caption.
3. **Keep the machine, change the message.** Same hook skeleton, beats, length, and payoff. New message, angle, and voice.
4. **Your words beat AI words.** Pull real lines from your calls, voice notes, and posts into the middle of every script.
5. **A human reads every script before it is filmed.** If it would not feel natural to say on camera, it does not ship.

## What this kit is not

- It is not a done-for-you service and it does not include video editing.
- It does not guarantee views, leads, or revenue. A proven format raises your odds. Delivery on camera and consistency still matter.
- It does not include paid tool accounts. You choose your own plans. The Cost Breakdown shows exactly what each one costs.

Questions about the kit: DM @cristianaguilar.ai on Instagram.
