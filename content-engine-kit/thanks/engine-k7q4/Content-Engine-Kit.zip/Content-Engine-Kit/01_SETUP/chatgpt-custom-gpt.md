# Setup: ChatGPT (custom GPT or Project, about 15 minutes)

Custom GPTs and Projects need a paid ChatGPT plan (see the Cost Breakdown). On Free, paste the instructions at the top of a chat and attach files instead.

## Option A: Custom GPT
1. In ChatGPT, open **GPTs**, then **Create**, then the **Configure** tab (menu names can change).
2. Name: "Content Engine". Description: "Runs my outlier research, hooks, and Format DNA scripts."
3. **Instructions:** paste the same instruction block from claude-project.md.
4. **Knowledge:** upload brand-intake.md, phrase-bank.md, format-vault.csv, hook-bank.csv, and the files in 02_WORKFLOWS and 03_PROMPTS.
5. **Capabilities:** turn on Web Search and Code Interpreter (Code Interpreter runs the outlier math on CSVs).
6. **Conversation starters:** "Run outlier ranking on this CSV", "Write a Format DNA script", "QA this week's batch", "Plan my week".
7. Keep it private (Only me) unless you want to share it with a team.

## Option B: ChatGPT Project
1. Create a **Project** called "Content Engine".
2. Paste the instruction block into the project instructions.
3. Upload the same files to the project.
4. Chat inside the project using prompts from 03_PROMPTS.
