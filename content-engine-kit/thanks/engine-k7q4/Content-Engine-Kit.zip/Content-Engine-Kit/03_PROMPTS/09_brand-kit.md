# Prompt 09: Brand Kit

---
Using my brand intake (in project knowledge), write a one-page brand kit:
1. Colors: 2 to 3 brand colors, 1 accent, 1 background, with hex codes and where each is used
2. Fonts: 1 headline, 1 body (free Google Fonts), with sizes for story, carousel, and reel text
3. On-screen text rules: case, max words per line, placement, safe zones for 1080x1920 (keep text out of the top and bottom 250 px)
4. Caption rules: hook first line, short lines, one CTA, hashtag policy
5. Voice rules: from my do-not-say list
6. A 10-item checklist I can run before posting anything

No em dashes.
