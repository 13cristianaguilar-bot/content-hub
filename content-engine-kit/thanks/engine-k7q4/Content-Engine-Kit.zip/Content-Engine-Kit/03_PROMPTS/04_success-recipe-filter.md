# Prompt 04: Success Recipe Filter

---
Below is outlier research for creators who use the format: [FORMAT NAME].

For each creator, tell me whether they REUSED the format after an outlier (a true recipe) or hit once (a one-off).
Keep only true recipes. For each keeper return: handle, niche, format name, growth signal (what changed after they doubled down, only from the data given), and the best 2 to 3 reel URLs with views, median, and multiple.

Then check each keeper against my brand thesis (in project knowledge). Drop any whose topics would force me off-thesis, even if the format fits.

Finish with a recipe card for the strongest anchor:
format name | anchor URL | spoken hook (leave blank for me to fill from audio) | length (s) | beats in order | payoff | backup references.

RESEARCH:
[paste]
