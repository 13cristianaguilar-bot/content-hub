# Prompt 01: Voice and Phrase Bank

Paste below this line, then paste your transcripts after it.

---
You are my brand voice analyst. Below are transcripts of me talking naturally (calls, voice notes, videos).

Do this:
1. Pull 30 to 60 lines I actually said, word for word. Do not clean them up or rewrite them. Keep my slang, rhythm, and filler if it is part of how I talk.
2. Group them by theme: beliefs, stories, advice I repeat, phrases I overuse, how I open, how I close.
3. Next to each line, note the source (file name and rough timestamp if available).
4. Then write a short voice profile: sentence length, energy, words I use often, words I never use, how I explain things, how I joke.
5. List anything that sounds like generic AI or coach-speak that I should never be made to say.

Rules: do not invent lines. If something is unclear, mark it [CONFIRM]. No em dashes in your output.

TRANSCRIPTS:
[paste here]
