# Prompt 03: 7-Part Breakdown

---
Break down this outlier reel. I watched or transcribed it myself; the transcript of the first 30 seconds and what I saw on screen are below.

Return the 7 parts:
1. HOOK: the exact spoken hook (from the transcript, not the caption) and the exact on-screen text in the first 3 seconds
2. FORMAT: the visible structure (talking head, list, reaction, story, myth-buster, tutorial), cuts, props, framing, length in seconds
3. IDEA: the core idea in one sentence
4. REWARD: what the viewer gets by watching to the end
5. CTA: what they are asked to do
6. ANGLE: the point of view or framing
7. MESSAGING: the specific words and examples used

Then tell me: which of the 7 parts I should KEEP (hook, format, idea, reward, CTA) and draft how ANGLE and MESSAGING would change for my brand (brand intake attached in project knowledge).

REEL: [URL] | views: [ ] | creator median: [ ] | multiple: [ ]
TRANSCRIPT (first 30s): [ ]
ON SCREEN: [ ]
